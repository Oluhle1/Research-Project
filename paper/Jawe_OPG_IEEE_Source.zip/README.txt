Portable IEEE source: Jawe OPG non-receipt paper

Main paper revised on 22 October 2026 only at the six locations raised by the
supervisor. The PDF has eight Letter pages, nine tables and four figures.
Table VI now identifies all sixteen scenarios separately; numerical results,
all other tables, headings, figures and unrelated manuscript text are preserved.
No survey records are included. Exact source hashes appear in the build manifest.

After extraction, compile twice with TeX Live or MiKTeX:
  pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error Jawe_OPG_nonreceipt_KZN.tex
  pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error Jawe_OPG_nonreceipt_KZN.tex

The unchanged IEEEtran.cls V1.8b (2015/08/26) and figures are included.
Standard packages required by the preamble include fontenc, inputenc, textcomp,
graphicx, array, tabularx, cite, placeins and url. No absolute paths or external
retrievals are required. The source uses IEEEtran's documented column break at
reference16 and normal reference leading; no font/margin/leading compression.

IEEEtran.cls retains its full contributor and LPPL1.3 notices. See
https://www.latex-project.org/lppl/ and TEMPLATE_PROVENANCE.md.

The ethics statement records the supervisor guidance supplied by the author.
The author has now supplied catalogue text describing the edited/anonymised
version1.1 dataset (18 September2017) as public access and for public distribution,
with DOI10.25828/9229-xz60. Dataset reference29 is separate from metadata reference21.
No new successful provider HTTP request or review of every historical repository
file is claimed. Earlier journal/DOI/thesis retrieval limits remain unchanged.

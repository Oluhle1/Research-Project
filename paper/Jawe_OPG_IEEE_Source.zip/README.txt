Portable IEEE source: Jawe OPG non-receipt paper

Generated from paper/manuscript.md and references.json on 21 October 2026.
The PDF has 8 Letter pages; the companion supplement is separate.
No survey records are included. Source/audit hashes are in the manifest.

Build after extracting with a standard TeX Live or MiKTeX installation:
  pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error Jawe_OPG_nonreceipt_KZN.tex
  pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error Jawe_OPG_nonreceipt_KZN.tex

Requires IEEEtran.cls (included unchanged) and standard TeX packages listed
in the generated preamble: cite, graphicx, array, tabularx, url, placeins,
amsmath and textcomp. No absolute paths or external downloads are needed.
The source uses IEEEtran's documented IEEEtriggeratref{16} column break.
No geometry, font-size or reference-leading compression is applied.

IEEEtran.cls V1.8b (2015/08/26) is distributed unmodified under LPPL 1.3;
retain its full license header and contributor notices. See
https://www.latex-project.org/lppl/ and TEMPLATE_PROVENANCE.md.

Bibliographic status: three retained Stats SA primary PDFs were inspected locally.
The 18 journal DOI and thesis repository checks remain pending because the
HTTPS proxy refused requests before origin access. The compiled reference
list must not be described as fully independently verified.

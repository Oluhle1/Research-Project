Portable IEEE source: Jawe OPG non-receipt paper

Main paper revised on 22 October 2026 only at the six locations raised by the
supervisor. The PDF has eight Letter pages, nine tables and four figures.
Table VI now identifies all sixteen scenarios separately; numerical results,
all other tables, headings, figures and unrelated manuscript text are preserved.
No survey records are included. Exact source hashes appear in the build manifest.

After extraction, compile twice with TeX Live or MiKTeX:
  pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error Jawe_OPG_nonreceipt_KZN.tex
  pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error Jawe_OPG_nonreceipt_KZN.tex

The unchanged IEEEtran.cls V1.8b (2015/08/26) and figures are included.
Standard packages required by the preamble include fontenc, inputenc, textcomp,
graphicx, array, tabularx, cite, placeins and url. No absolute paths or external
retrievals are required. The source uses IEEEtran's documented column break at
reference16 and normal reference leading; no font/margin/leading compression.

IEEEtran.cls retains its full contributor and LPPL1.3 notices. See
https://www.latex-project.org/lppl/ and TEMPLATE_PROVENANCE.md.

The ethics statement records the supervisor guidance supplied by the author.
It does not claim a research-ethics committee letter or redistribution licence.
The author-supplied DataFirst catalogue link replaces project archive links in
the references. Official catalogue access/release terms remain unverified after
proxy403 errors. Publisher/DOI/thesis limits from the prior revision remain.

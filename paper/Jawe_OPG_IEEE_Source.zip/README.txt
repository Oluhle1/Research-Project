Portable IEEE source: Jawe OPG non-receipt paper — 26 October 2026

The main PDF remains eight Letter pages with nine tables, four figures and
29 references. The second-feedback revision changes only targeted source/method
clarifications, Table V's weighted/unweighted layout, the principal contribution
sentence and verified government-notice page locators. Already-addressed material,
numerical results and the separate supplement are preserved.

After extraction, compile twice using TeX Live or MiKTeX:
  pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error Jawe_OPG_nonreceipt_KZN.tex
  pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error Jawe_OPG_nonreceipt_KZN.tex

The unchanged IEEEtran.cls V1.8b and all four figures are included. Standard
preamble packages include fontenc, inputenc, textcomp, graphicx, array, tabularx,
cite, placeins and url. No absolute paths or external retrievals are required.
Class typography remains standard: body10pt, tables9pt, references8pt/9pt.
Table V uses grouped recipient/non-recipient headers with separate unweighted
and weighted columns. No table image or font scaling is used.

Retain the unmodified class's contributor and LPPL1.3 notices. See
https://www.latex-project.org/lppl/ and TEMPLATE_PROVENANCE.md.

Original legal/survey PDFs were rechecked locally. Fresh publisher, DOI and
thesis requests were blocked by the proxy before source access; metadata was not
independently obtained. The audit records this limit. No new model, bootstrap,
search or participant usability study was conducted for this revision.

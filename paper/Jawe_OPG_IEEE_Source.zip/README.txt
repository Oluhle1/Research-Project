Final IEEE source with Table S5 inside the main paper — 28 October 2026

The final main paper remains eight Letter pages. It now visibly includes all
eight exact recorded queries, the 17 August 2026 date, and source-specific hits/retained counts.
S5 is a full-width eight-row record in the literature review; all nine original numbered
tables, four figures, 29 references and unrelated manuscript text are preserved.

Compile twice after extraction with TeX Live or MiKTeX:
  pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error Jawe_OPG_nonreceipt_KZN.tex
  pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error Jawe_OPG_nonreceipt_KZN.tex

Do not add a manual reference-column break: natural IEEE flow fits eight pages with S5.
The unmodified IEEEtran.cls V1.8b, four figures and manifest are included. Standard
preamble packages include fontenc, inputenc, textcomp, graphicx, array, tabularx, cite,
placeins and url. No absolute paths or external retrievals are required.

Original body/table/reference typography remains 10/9/8 points. The new search
record uses standard IEEE footnotesize 8/9; no existing font or leading was reduced.
The queries are exact historical records; no new search or model was run.

Retain the class's full licence and contributor notices (LPPL 1.3).
See https://www.latex-project.org/lppl/ and TEMPLATE_PROVENANCE.md.
Reference verification remains author-confirmed as recorded in the project.

Final supervisor checks clarify S5 counts, singular hit wording and institutional guidance.
Supplementary S4 now gives interpretation notes instead of repeating Table V.

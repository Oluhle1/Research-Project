Main paper: paper/Jawe_OPG_nonreceipt_KZN.docx and .pdf (8 pages).
Companion: paper/Jawe_OPG_Supplementary_Material.docx and .pdf (11 pages).
Only the supplementary-evidence item was updated. S5 contains author-recorded queries and aggregate counts, not original database exports or a reconstructed screening log.
The evidence folders contain aggregate tables, tuning records and analysis source; no respondent-level files are included. The scripts require the repository environment and controlled cohort for execution.

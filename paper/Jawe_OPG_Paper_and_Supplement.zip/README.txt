Main paper and supplementary evidence — 22 October 2026

The main Word and native IEEE PDF incorporate only the six points in the latest
supervisor feedback. Both remain eight Letter pages, including references.
Read paper/supervisor_final_feedback_2026-10-22.md for the point-by-point response.
The structure, unrelated text, other eight tables, four figures and numerical
results are preserved. Table VI identifies all sixteen scenarios separately.

Ethics wording follows the supervisor guidance supplied by the author. Dataset
provenance uses the author's DataFirst catalogue608 link. Public redistribution
terms for survey files, two supporting documents and historical repository
contents remain unconfirmed; provider access was blocked by the environment.

The supplement remains an unchanged separate11-page companion. Aggregate
computational evidence and recorded searches are preserved from earlier releases;
no new fit, application test, search or participant study is claimed. The package
uses a bounded document/source/aggregate allowlist. Survey records, cohort files,
OOF prediction records and respondent identifiers are excluded.

For a portable native IEEE build, extract paper/Jawe_OPG_IEEE_Source.zip and use
its README. The unmodified class retains its licence and contributor notices.
Earlier dated audit records retain their historical scope and limits.

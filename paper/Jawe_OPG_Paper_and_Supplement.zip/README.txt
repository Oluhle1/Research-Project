Main paper and supplementary evidence — 26 October 2026

The author has confirmed verifying every reference and the legitimacy of the DOI
addresses. The final reference-check feedback item is marked addressed on that
basis. This confirmation is attributed to the author; historical blocked assistant
requests remain unchanged as a record of tool access limits.

The main paper is unchanged by this status update: eight Letter pages, nine tables,
four figures and29references. The existing six-point/twelve-row feedback response
now records the author confirmation. Read paper/second_supervisor_feedback_2026-10-26.md
and paper/reference_author_confirmation_2026-10-26.json.

The supplement, scientific results, source package and all numeric estimates are
preserved. No new fit, test, search, reference retrieval or render is claimed.
This bounded document/source/aggregate package excludes survey rows, cohort files
and respondent-level predictions. Earlier audits retain their dated scope.

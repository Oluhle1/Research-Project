Main paper and supplementary evidence — 26 October 2026

The second-feedback revision edits only remaining gaps. Already-addressed
literature/proxy, coefficient, bootstrap, ethics and usability passages are
preserved. Read paper/second_supervisor_feedback_2026-10-26.md for all six user
points and all twelve rows in the attached supervisor PDF.

Main Word/native IEEE PDF: eight Letter pages, nine tables, four figures and
29 references. TableV separates unweighted/weighted values within receipt groups;
all statistics are preserved. Government/survey originals were read again and
four monetary boundaries checked. Model coding remains explicitly exploratory;
internal CV is not external validation. The principal workflow contribution is
now stated directly. No new model fit, bootstrap, search, application test or
participant study was performed for this document revision.

Fresh publisher/DOI/thesis verification remains blocked:63requests returned
proxyCONNECT403 beforeorigin access, with no authoritative metadata obtained.
The dated audit records this accurately. Prior source and computational evidence
retain their original scope and dates. No new institutional or blanket repository
clearance is claimed.

The unchanged supplement remains a separate eleven-page companion. The package
uses a bounded document/source/aggregate allowlist and excludes survey records,
cohort files and respondent-level predictions. Extract the portable IEEE source
ZIP and follow its README for a standalone native build.

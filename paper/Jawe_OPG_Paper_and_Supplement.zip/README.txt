Final paper with Table S5 inside the main copy — 26 October 2026

The main Word and native IEEE PDF are each eight pages. All eight exact recorded
search strings, the common17August2026date and source-specific hit/retained counts
are now visibly included as TableS5 within the main paper. The selection flow and
synthesis explanation remain in II.A. You do not need the separate supplement to
see this search record. See paper/s5_main_inclusion_2026-10-26.md/json for checks.

All original numbered tables I–IX, four figures,29references, numerical results
and unrelated main text are preserved. The separate eleven-page supplement is
unchanged and still supplied. References remain author-verified; historical tool
access limits remain in their dated records. No new search, model or participant
study was conducted for this inclusion.

The portable IEEE source ZIP compiles without a manual reference-column break.
Its README gives the standalone commands. The package contains bounded documents,
source and aggregate evidence; survey records and respondent predictions are
excluded. Earlier evidence and audit records retain their dated scope.

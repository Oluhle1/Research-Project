Main paper and supplementary evidence — 22 October 2026

The six supervisor corrections are preserved. The follow-up catalogue text
supplied by the author confirms that the named edited/anonymised dataset is
version1.1 (18September2017), is public access/for public distribution, and has
DOI10.25828/9229-xz60. The paper now includes the required dataset citation as
reference29, distinct from the metadata document at21. No new HTTP retrieval
or review of every historical repository file is claimed.

Only the ethics/access paragraph and related references changed in this follow-up.
The main Word and IEEE PDF remain eight pages with nine tables/four figures.
All existing citation numbers1–28, other text, numerical results, tables, figures,
models and supplement are preserved. The supplement remains a separate11pages.

The dated response and catalogue evidence identify what was supplied, checked
and not independently verified. Earlier failed-request records remain historical.
The package uses a bounded document/source/aggregate allowlist; survey rows,
cohort files and respondent-level OOF prediction records are excluded.
Extract the portable IEEE source ZIP and follow its README to compile the paper.

Updated paper and supplementary evidence — 21 October 2026

Main Word and native IEEE PDF: 8 pages including all sections and references.
Supplementary Word/PDF: unchanged, separate 11-page Tables S1–S5 companion.
The generated manuscript source, bibliography, IEEE builders and portable TeX
package are included. Native IEEE reference leading is 8-point text/9-point
baseline; the Word counterpart uses normal single spacing. Nine source tables,
four figures, screening rules and validation methods remain unchanged.

Source verification: read paper/reference_revision.md. Three Stats SA primary
files were inspected locally and their dates, archive versions and inspection
details clarified. Live verification of 18 journal DOI records and the thesis
remains blocked by the environment proxy; no authoritative remote metadata was
retrieved. Existing journal/thesis factual fields were preserved.

The aggregate evidence and S1–S5 files are unchanged from the preceding release.
No new model fit, application test or participant usability study is claimed.
The package uses an explicit aggregate/document/source allowlist and excludes
survey rows, respondent identifiers, cohort files and OOF prediction records.
Recorded searches are historical author records, not newly run searches.
Consult the dated computational evidence and source audits for their limits.

For native TeX compilation, extract paper/Jawe_OPG_IEEE_Source.zip and follow its
README.txt. The included IEEEtran class is unmodified and retains LPPL notices.

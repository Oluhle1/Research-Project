Publication-profile IEEE source for Oluhle Jawe

This bundle contains the complete paper, inline bibliography, four original figures and the unmodified IEEEtran V1.8b class. It contains no survey data. The course/student line is omitted.

Requires pdflatex with fontenc, inputenc, textcomp, graphicx, array, tabularx, cite, url and placeins. Compile twice from this folder:
  pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error Jawe_OPG_nonreceipt_KZN.tex

The final paper uses IEEEtran conference/letterpaper/10pt defaults and native reference balancing at reference 9. It contains eight pages, including references.

IEEEtran.cls is supplied under LPPL 1.3 with its complete original notices. Source: rstudio/rticles commit accdfa39225570a8ad9b786fbb3077060d1e12a5, inst/rmarkdown/templates/ieee/skeleton/IEEEtran.cls. SHA256 a9d9562028ce6e8af1ea0b5740e435d04be3d6c745ca2a3c2979564274b44cea.

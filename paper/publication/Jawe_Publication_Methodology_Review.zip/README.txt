Publication methodology review — 28 October 2026

Read paper/publication/README.md and the six-page Word/PDF review note first.
This package contains the new validation code, focused tests, protocol, aggregate
results, diagrams and numerical/visual checks. It is not an IST-Africa submission.
The submitted Honours paper and production application/model are unchanged.
The original primary model remains exploratory. No external validation or
participant usability study is claimed; Monte Carlo errors are not sampling CIs.

The review excludes survey microdata, respondent identifiers and row-level
predictions. Reanalysis requires the provider-accessed data and frozen cohort
described in the repository. See release_manifest.json for exact artifact hashes.

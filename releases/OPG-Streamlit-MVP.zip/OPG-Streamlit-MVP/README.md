# OPG Streamlit MVP — local demonstration

Extract this entire folder and use Python 3.12 (64-bit).
Open PowerShell in this folder on Windows, then run:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements-app.txt
.\.venv\Scripts\python.exe tools\run_app.py
```

Open http://localhost:8501 on your computer. Click **Use synthetic example**,
then **Run analysis**. Explore results, predictions and report exports using
the sidebar. Leave the terminal open. Press Ctrl+C to stop the app.
For future sessions, run only the last command.

See [Windows setup](docs/windows_setup.md) for Python installation and
troubleshooting, and [the data dictionary](docs/data_dictionary.md) for uploads.
Virtual-environment activation and Git are unnecessary.

On macOS/Linux, use `python3.12 -m venv .venv`, then
`.venv/bin/python -m pip install -r requirements-app.txt` and
`.venv/bin/python tools/run_app.py`.

This package contains app code, a frozen JSON model, aggregate evaluation,
and the scientific source modules needed at runtime. It contains no historical
survey datasets, respondent outputs or Git history. Preserve the scientific
source files unchanged; the model verifies their exact bytes.

The app is a historical LCS 2014/2015 KwaZulu-Natal research prototype.
Observable screening is not a statutory eligibility or grant decision.
Model probabilities describe reported non-receipt; upload scoring does not
train a model or establish held-out performance on the uploaded data.

`PACKAGE_CONTENTS.sha256` records the files included in this package.
